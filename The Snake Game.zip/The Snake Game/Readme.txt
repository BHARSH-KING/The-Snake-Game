This game was made using python.

the copyright belongs to Harsh B.



Play and take your screenshots of high scores and share with us



my personal best 610

break it.



Enjoy the classic game and enjoy.

